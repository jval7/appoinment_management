class FieldNotFoundError(Exception):
    ...


class InvalidCrudType(Exception):
    ...


class InvalidModelParams(Exception):
    ...
