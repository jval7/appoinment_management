from app.appointment_management.domain.exceptions import FieldNotFoundError

__all__ = ["FieldNotFoundError"]
